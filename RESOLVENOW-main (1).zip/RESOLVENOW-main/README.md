# ResolveNow

Your Platform for Online Complaints  
A MERN stack web app developed during the SmartInternz Internship for complaint registration, tracking, and resolution.
