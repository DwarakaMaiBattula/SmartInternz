📽️ App.Demo

👉 [Click to access the App.Demo](https://drive.google.com/file/d/1RRF34M8DiE24LamnBjGNdvaJyxojTlgx/view?usp=sharing)
This App.Demo provides a detailed walkthrough of the ResolveNow platform. It highlights key functionalities such as complaint registration, user/admin dashboards, and real-time tracking. The markdown file includes screenshots and feature explanations for better clarity. It serves as a quick guide for understanding the user journey and interface.
